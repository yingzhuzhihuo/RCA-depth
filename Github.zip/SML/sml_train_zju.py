import sys
import os, datetime
import argparse
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import data.data_utils as data_utils
from sml_main import train


def parse_args():
    repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    default_root = os.environ.get('ZJU_ROOT', os.path.join(repo_root, 'data', 'ZJU-4DRadarCam'))
    parser = argparse.ArgumentParser(description='Train SML on ZJU-4DRadarCam.')
    parser.add_argument('--data-root', default=os.path.join(default_root, 'data'))
    parser.add_argument('--result-root', default=os.path.join(default_root, 'result'))
    parser.add_argument('--log-root', default=os.path.join(default_root, 'log', 'SML'))
    parser.add_argument('--train-split', default=None)
    parser.add_argument('--restore-path', default='')
    parser.add_argument('--batch-size', type=int, default=36)
    parser.add_argument('--n-threads', type=int, default=16)
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_args()
    train_root = args.data_root
    result_root = args.result_root
    current_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

    image_path = os.path.join(train_root, 'image/')
    radar_path = os.path.join(train_root, 'radar_png/')
    gt_path = os.path.join(train_root, 'gt_interp/')
    sparse_gt_path = os.path.join(train_root, 'gt/')
    mono_ga_path = os.path.join(result_root, 'global_aligned_mono/dpt_var/')
    rcnet_path = os.path.join(result_root, 'rcnet/depth_predicted/')
    train_list = args.train_split or os.path.join(train_root, 'train.txt')

    train_image_paths = data_utils.load_data_path(image_path, train_list, '.png')
    train_radar_paths = data_utils.load_data_path(radar_path, train_list, '.png')
    train_gt_paths = data_utils.load_data_path(gt_path, train_list, '.png')
    train_sparse_gt_paths = data_utils.load_data_path(sparse_gt_path, train_list, '.png')
    train_rcnet_paths = data_utils.load_data_path(rcnet_path, train_list, '.png')
    train_mono_ga_paths = data_utils.load_data_path(mono_ga_path, train_list, '.png')


    train(
        # data input
        train_image_paths = train_image_paths,
        train_radar_paths = train_radar_paths,
        train_gt_paths = train_gt_paths,
        train_sparse_gt_paths = train_sparse_gt_paths,
        train_rcnet_paths = train_rcnet_paths,
        train_mono_ga_paths = train_mono_ga_paths,

        # training
        learning_rates = [2.44e-4, 1.22e-4, 6.1e-5],
        learning_schedule = [20, 45, 100],
        batch_size = args.batch_size,
        n_step_per_summary = 1000,
        n_step_per_checkpoint = 2000,

        # Loss settings
        loss_func = 'smoothl1',
        w_smoothness = 0.0,
        w_lidar_loss = 3.0,
        w_weight_decay = 0.0,
        loss_smoothness_kernel_size = -1,
        ground_truth_outlier_removal_kernel_size = -1,
        ground_truth_outlier_removal_threshold = 1.5,
        ground_truth_dilation_kernel_size = -1,

        # model
        restore_path = args.restore_path,
        min_pred_depth = 0.1,
        max_pred_depth = 100.0,
        min_radar_valid_depth = 0.0,
        max_radar_valid_depth = 80.0,
        checkpoint_dirpath = os.path.join(args.log_root, current_time),
        n_threads=args.n_threads,
    )
