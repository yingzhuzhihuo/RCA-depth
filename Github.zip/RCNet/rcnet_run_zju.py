import sys
import os
import argparse
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rcnet_main import run
import data.data_utils as data_utils


def parse_args():
    repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    default_root = os.environ.get('ZJU_ROOT', os.path.join(repo_root, 'data', 'ZJU-4DRadarCam'))
    parser = argparse.ArgumentParser(description='Run RCNet on ZJU-4DRadarCam.')
    parser.add_argument('--root', default=default_root)
    parser.add_argument('--save-root', default=None)
    parser.add_argument('--split-file', default=None)
    parser.add_argument('--restore-path', default=os.path.join(repo_root, 'weights', 'rcnet', 'model-128000.pth'))
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_args()
    root = args.root
    save_root = args.save_root or os.path.join(root, 'result', 'rcnet')
    image_path = os.path.join(root, 'data/image/')
    radar_path = os.path.join(root, 'data/radar/')
    gt_path = os.path.join(root, 'data/gt_interp/')
    data_list = args.split_file or os.path.join(root, 'data/full.txt')

    image_paths = data_utils.load_data_path(image_path, data_list, '.png')
    radar_paths = data_utils.load_data_path(radar_path, data_list, '.npy')
    gt_paths = data_utils.load_data_path(gt_path, data_list, '.png')

    run(save_root = save_root,
        image_paths = image_paths,
        radar_paths = radar_paths,
        gt_paths = gt_paths,

        restore_path = args.restore_path,
        patch_size = [300, 100],
        normalized_image_range = [0, 1],

        encoder_type = ['rcnet', 'batch_norm'],
        n_filters_encoder_image = [32, 64, 128, 128, 128],
        n_neurons_encoder_depth = [32, 64, 128, 128, 128],
        decoder_type = ['multiscale', 'batch_norm'],
        n_filters_decoder = [256, 128, 64, 32, 16],
        weight_initializer = 'kaiming_uniform',
        activation_func = 'leaky_relu',
        response_thr = 0.5)
    



