from data.global_alignment import *  # noqa: F401,F403

if __name__ == '__main__':
    import runpy

    runpy.run_module('data.global_alignment', run_name='__main__')
