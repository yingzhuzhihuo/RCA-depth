import torch
import torch.nn as nn

from torch.nn import functional as F

from .base_model import BaseModel
from .blocks import FeatureFusionBlock_custom, _make_encoder, OutputConv, NWCOutputHead

def weights_init(m):
    import math
    # initialize from normal (Gaussian) distribution
    if isinstance(m, nn.Conv2d):
        n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
        m.weight.data.normal_(0, math.sqrt(2.0 / n))
        if m.bias is not None:
            m.bias.data.zero_()
    elif isinstance(m, nn.BatchNorm2d):
        m.weight.data.fill_(1)
        m.bias.data.zero_()


class MidasNet_small_videpth(BaseModel):
    """Network for monocular depth estimation.
    """

    def __init__(self, device = 'cpu', path=None, features=64, backbone="efficientnet_lite3", non_negative=False, exportable=True, channels_last=False, align_corners=True,
        blocks={'expand': True}, in_channels=2, regress='r', min_pred=None, max_pred=None, use_nwc_head=False, nwc_kernel_size=3,
        use_uncertainty_head=False, min_log_var=-3.0, max_log_var=3.0):
        """Init.

        Args:
            path (str, optional): Path to saved model. Defaults to None.
            features (int, optional): Number of features. Defaults to 64.
            backbone (str, optional): Backbone network for encoder. Defaults to efficientnet_lite3.
        """
        print("Loading weights: ", path)

        super(MidasNet_small_videpth, self).__init__()

        use_pretrained = False if path else True
                
        self.channels_last = channels_last
        self.blocks = blocks
        self.backbone = backbone

        self.groups = 1

        # for model output
        self.regress = regress
        self.min_pred = min_pred
        self.max_pred = max_pred
        self.use_nwc_head = use_nwc_head
        self.nwc_kernel_size = nwc_kernel_size
        self.use_uncertainty_head = use_uncertainty_head
        self.min_log_var = min_log_var
        self.max_log_var = max_log_var

        features1=features
        features2=features
        features3=features
        features4=features
        self.expand = False
        if "expand" in self.blocks and self.blocks['expand'] == True:
            self.expand = True
            features1=features
            features2=features*2
            features3=features*4
            features4=features*8

        self.first = nn.Sequential(
            nn.Conv2d(in_channels, 3, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(3),
            nn.ReLU(inplace=True)
        )
        self.first.apply(weights_init)

        self.pretrained, self.scratch = _make_encoder(self.backbone, features, use_pretrained, groups=self.groups, expand=self.expand, exportable=exportable)

        self.scratch.activation = nn.ReLU(False)    

        self.scratch.refinenet4 = FeatureFusionBlock_custom(features4, self.scratch.activation, deconv=False, bn=False, expand=self.expand, align_corners=align_corners)
        self.scratch.refinenet3 = FeatureFusionBlock_custom(features3, self.scratch.activation, deconv=False, bn=False, expand=self.expand, align_corners=align_corners)
        self.scratch.refinenet2 = FeatureFusionBlock_custom(features2, self.scratch.activation, deconv=False, bn=False, expand=self.expand, align_corners=align_corners)
        self.scratch.refinenet1 = FeatureFusionBlock_custom(features1, self.scratch.activation, deconv=False, bn=False, align_corners=align_corners)

        if self.use_nwc_head:
            self.scratch.output_conv = NWCOutputHead(
                features,
                self.groups,
                self.scratch.activation,
                non_negative,
                kernel_size=self.nwc_kernel_size,
            )
            print("Using NWC output head with {}x{} neighborhood".format(self.nwc_kernel_size, self.nwc_kernel_size))
        else:
            self.scratch.output_conv = OutputConv(features, self.groups, self.scratch.activation, non_negative)

        if self.use_uncertainty_head:
            self.scratch.uncertainty_head = nn.Sequential(
                nn.Conv2d(features1, features1 // 2, kernel_size=3, stride=1, padding=1, groups=self.groups),
                nn.Upsample(scale_factor=2, mode="bilinear"),
                nn.Conv2d(features1 // 2, 32, kernel_size=3, stride=1, padding=1),
                self.scratch.activation,
                nn.Conv2d(32, 1, kernel_size=1, stride=1, padding=0),
            )
            print("Using uncertainty head, log_var range=({}, {})".format(self.min_log_var, self.max_log_var))
        
        if path:
            self.load(path)

        self.to(device)


    def forward(self, x, d, use_nwc=None):
        """Forward pass.

        Args:
            x (tensor): input data (image)
            d (tensor): unalterated input depth

        Returns:
            tensor: depth
        """
        if self.channels_last==True:
            print("self.channels_last = ", self.channels_last)
            x.contiguous(memory_format=torch.channels_last)

        layer_0 = self.first(x)

        layer_1 = self.pretrained.layer1(layer_0)
        layer_2 = self.pretrained.layer2(layer_1)
        layer_3 = self.pretrained.layer3(layer_2)
        layer_4 = self.pretrained.layer4(layer_3)
        
        layer_1_rn = self.scratch.layer1_rn(layer_1)
        layer_2_rn = self.scratch.layer2_rn(layer_2)
        layer_3_rn = self.scratch.layer3_rn(layer_3)
        layer_4_rn = self.scratch.layer4_rn(layer_4)

        path_4 = self.scratch.refinenet4(layer_4_rn)
        path_3 = self.scratch.refinenet3(path_4, layer_3_rn)
        path_2 = self.scratch.refinenet2(path_3, layer_2_rn)
        path_1 = self.scratch.refinenet1(path_2, layer_1_rn)
        
        use_nwc_now = self.use_nwc_head if use_nwc is None else (self.use_nwc_head and use_nwc)

        # Predict pixel-wise log-variance (uncertainty) from the shared decoder
        # features first, so it can guide the NWC neighborhood aggregation below.
        if self.use_uncertainty_head:
            log_var = self.scratch.uncertainty_head(path_1)
            log_var = torch.clamp(log_var, min=self.min_log_var, max=self.max_log_var)
        else:
            log_var = None

        if self.use_nwc_head:
            out, nwc_logits, alpha = self.scratch.output_conv(path_1)
            scales = F.relu(1.0 + out)
            base_pred = d * scales

            if use_nwc_now:
                b, _, h, w = base_pred.shape
                k = self.nwc_kernel_size
                padded = F.pad(base_pred, (k // 2, k // 2, k // 2, k // 2), mode='replicate')
                neighborhood = F.unfold(padded, kernel_size=k, padding=0)
                neighborhood = neighborhood.view(b, k * k, h, w)

                # Uncertainty-guided neighborhood weighting: favor confident
                # neighbors (low log-variance) and suppress noisy ones. The
                # per-neighbor log-confidence -s(q) is added to the NWC logits
                # before the softmax, so uncertainty participates in inference.
                if log_var is not None:
                    conf = -log_var
                    conf_padded = F.pad(conf, (k // 2, k // 2, k // 2, k // 2), mode='replicate')
                    conf_neighborhood = F.unfold(conf_padded, kernel_size=k, padding=0)
                    conf_neighborhood = conf_neighborhood.view(b, k * k, h, w)
                    nwc_logits = nwc_logits + conf_neighborhood

                nwc_weights = torch.softmax(nwc_logits, dim=1)
                nwc_pred = torch.sum(nwc_weights * neighborhood, dim=1, keepdim=True)
                pred = base_pred + alpha * (nwc_pred - base_pred)
            else:
                pred = base_pred
        else:
            out = self.scratch.output_conv(path_1)
            scales = F.relu(1.0 + out)
            pred = d * scales

        # clamp pred to min and max
        if self.min_pred is not None:
            min_pred_inv = 1.0/self.min_pred
            pred[pred > min_pred_inv] = min_pred_inv
        if self.max_pred is not None:
            max_pred_inv = 1.0/self.max_pred
            pred[pred < max_pred_inv] = max_pred_inv

        # also return scales
        return (pred, scales, log_var)






