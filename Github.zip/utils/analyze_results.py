#!/usr/bin/env python3
"""
用于解析训练日志中的 results.txt，并生成论文风格可视化图。

示例：
    python utils/analyze_results.py \
        --root /home/ubuntu/Downloads/RadarCam-Depth/ZJU-4DRadarCam/log \
        --outdir /home/ubuntu/Downloads/RadarCam-Depth/result/analysis_figures \
        --metric RMSE
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


@dataclass
class Record:
    experiment: str
    model: str
    step: int
    MAE: float
    RMSE: float
    iMAE: float
    iRMSE: float
    Abs_Rel: float
    Sq_Rel: float
    Delta1: float
    source_file: str


METRICS = ["MAE", "RMSE", "iMAE", "iRMSE", "Abs_Rel", "Sq_Rel", "Delta1"]
LOWER_BETTER = {"MAE", "RMSE", "iMAE", "iRMSE", "Abs_Rel", "Sq_Rel"}
HIGHER_BETTER = {"Delta1"}


def setup_style() -> None:
    """统一论文风格绘图参数。"""
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "DejaVu Serif", "STIXGeneral"],
            "mathtext.fontset": "stix",
            "font.size": 11,
            "axes.labelsize": 12,
            "axes.titlesize": 13,
            "legend.fontsize": 10,
            "xtick.labelsize": 10,
            "ytick.labelsize": 10,
            "figure.dpi": 140,
            "savefig.dpi": 320,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def discover_result_files(root: Path, pattern: str = "**/results.txt") -> List[Path]:
    return sorted([p for p in root.glob(pattern) if p.is_file()])


def infer_meta(file_path: Path, root: Path) -> Dict[str, str]:
    """
    从路径推断模型名与实验名。
    例如: log/SML/20260331-221113/results.txt
    model=SML, experiment=SML_20260331-221113
    """
    rel = file_path.relative_to(root)
    parts = rel.parts

    if len(parts) >= 3:
        model = parts[0]
        exp = f"{parts[0]}_{parts[1]}"
    elif len(parts) == 2:
        model = parts[0]
        exp = f"{parts[0]}_{parts[1].replace('.txt', '')}"
    else:
        model = "unknown"
        exp = file_path.stem

    return {"model": model, "experiment": exp}


def parse_results_file(file_path: Path, root: Path) -> List[Record]:
    """解析 results.txt 中的数据行。"""
    text = file_path.read_text(encoding="utf-8", errors="ignore")
    if not text.strip():
        return []

    meta = infer_meta(file_path, root)

    # 兼容形如：
    # 6000  1157.025  3117.824  10.443  22.853  0.087  601.058  0.921
    row_pattern = re.compile(
        r"^\s*(\d+)\s+"
        r"([+-]?\d*\.?\d+)\s+"
        r"([+-]?\d*\.?\d+)\s+"
        r"([+-]?\d*\.?\d+)\s+"
        r"([+-]?\d*\.?\d+)\s+"
        r"([+-]?\d*\.?\d+)\s+"
        r"([+-]?\d*\.?\d+)\s+"
        r"([+-]?\d*\.?\d+)\s*$",
        flags=re.MULTILINE,
    )

    records: List[Record] = []
    for m in row_pattern.finditer(text):
        values = [float(m.group(i)) for i in range(2, 9)]
        rec = Record(
            experiment=meta["experiment"],
            model=meta["model"],
            step=int(m.group(1)),
            MAE=values[0],
            RMSE=values[1],
            iMAE=values[2],
            iRMSE=values[3],
            Abs_Rel=values[4],
            Sq_Rel=values[5],
            Delta1=values[6],
            source_file=str(file_path),
        )
        records.append(rec)

    return records


def to_dataframe(records: List[Record]) -> pd.DataFrame:
    if not records:
        return pd.DataFrame(columns=["experiment", "model", "step", *METRICS, "source_file"])
    return pd.DataFrame([r.__dict__ for r in records])


def select_best_per_experiment(df: pd.DataFrame, metric: str = "RMSE") -> pd.DataFrame:
    if df.empty:
        return df
    ascending = metric in LOWER_BETTER
    idx = df.groupby("experiment")[metric].idxmin() if ascending else df.groupby("experiment")[metric].idxmax()
    return df.loc[idx].sort_values(metric, ascending=ascending).reset_index(drop=True)


def plot_metric_bar(best_df: pd.DataFrame, outdir: Path, metric: str) -> Optional[Path]:
    if best_df.empty or metric not in best_df.columns:
        return None

    ascending = metric in LOWER_BETTER
    view = best_df.sort_values(metric, ascending=ascending).reset_index(drop=True)

    fig, ax = plt.subplots(figsize=(10, 4.8))
    colors = ["#4C72B0"] * len(view)
    if len(view) > 0:
        colors[0] = "#C44E52"  # 突出最佳

    ax.bar(view["experiment"], view[metric], color=colors, alpha=0.92)
    ax.set_xlabel("Experiment")
    ax.set_ylabel(metric)
    direction = "↓ lower is better" if ascending else "↑ higher is better"
    ax.set_title(f"Best {metric} across experiments ({direction})")
    ax.tick_params(axis="x", rotation=35)

    for i, val in enumerate(view[metric].to_numpy()):
        ax.text(i, val, f"{val:.3f}", ha="center", va="bottom", fontsize=8, rotation=90)

    fig.tight_layout()
    path = outdir / f"bar_best_{metric}.png"
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


def _normalized_scores(df: pd.DataFrame) -> pd.DataFrame:
    """把不同量纲指标归一化到 [0,1]，统一为“越大越好”的分数。"""
    score_df = df.copy()
    for m in METRICS:
        vals = score_df[m].to_numpy(dtype=float)
        vmin, vmax = np.nanmin(vals), np.nanmax(vals)
        if np.isclose(vmin, vmax):
            score_df[m] = 1.0
            continue
        if m in LOWER_BETTER:
            score_df[m] = (vmax - vals) / (vmax - vmin)
        else:
            score_df[m] = (vals - vmin) / (vmax - vmin)
    return score_df


def plot_radar(best_df: pd.DataFrame, outdir: Path, top_k: int = 6) -> Optional[Path]:
    if best_df.empty:
        return None

    view = best_df.copy()
    view = view.sort_values("RMSE", ascending=True).head(top_k).reset_index(drop=True)
    score_df = _normalized_scores(view)

    labels = METRICS
    n = len(labels)
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False).tolist()
    angles += angles[:1]

    fig = plt.figure(figsize=(7.2, 6.8))
    ax = fig.add_subplot(111, polar=True)

    for i, row in score_df.iterrows():
        values = row[labels].to_list()
        values += values[:1]
        ax.plot(angles, values, linewidth=1.8, label=view.loc[i, "experiment"])
        ax.fill(angles, values, alpha=0.08)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels)
    ax.set_yticklabels([])
    ax.set_title("Normalized multi-metric comparison (higher is better)", pad=18)
    ax.legend(loc="upper right", bbox_to_anchor=(1.30, 1.15), frameon=True)

    fig.tight_layout()
    path = outdir / "radar_multimetric.png"
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_metric_curve(df: pd.DataFrame, outdir: Path, metric: str = "RMSE") -> Optional[Path]:
    if df.empty or metric not in df.columns:
        return None

    # 只保留至少有 2 个 step 的实验
    valid_exps = []
    for exp, g in df.groupby("experiment"):
        if g["step"].nunique() >= 2:
            valid_exps.append(exp)

    if not valid_exps:
        return None

    fig, ax = plt.subplots(figsize=(8.6, 4.8))
    sub = df[df["experiment"].isin(valid_exps)].copy()

    for exp, g in sub.groupby("experiment"):
        g = g.sort_values("step")
        ax.plot(g["step"], g[metric], marker="o", linewidth=1.8, markersize=3.5, label=exp)

    ax.set_xlabel("Training step")
    ax.set_ylabel(metric)
    ax.set_title(f"{metric} evolution over checkpoints")
    ax.legend(ncol=2, frameon=True)
    ax.grid(True, linestyle="--", alpha=0.35)

    fig.tight_layout()
    path = outdir / f"curve_{metric}.png"
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


def summarize(df: pd.DataFrame, outdir: Path, metric: str) -> Dict[str, Optional[Path]]:
    outdir.mkdir(parents=True, exist_ok=True)

    all_csv = outdir / "all_records.csv"
    best_csv = outdir / f"best_per_experiment_by_{metric}.csv"
    df.to_csv(all_csv, index=False)

    best_df = select_best_per_experiment(df, metric=metric)
    best_df.to_csv(best_csv, index=False)

    files = {
        "all_csv": all_csv,
        "best_csv": best_csv,
        "bar": plot_metric_bar(best_df, outdir=outdir, metric=metric),
        "radar": plot_radar(best_df, outdir=outdir, top_k=6),
        "curve": plot_metric_curve(df, outdir=outdir, metric=metric),
    }
    return files


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="解析 results.txt 并生成学术风格可视化")
    parser.add_argument(
        "--root",
        type=Path,
        default=Path("/home/ubuntu/Downloads/RadarCam-Depth/ZJU-4DRadarCam/log"),
        help="results.txt 搜索根目录",
    )
    parser.add_argument(
        "--glob",
        type=str,
        default="**/results.txt",
        help="搜索模式",
    )
    parser.add_argument(
        "--outdir",
        type=Path,
        default=Path("/home/ubuntu/Downloads/RadarCam-Depth/result/analysis_figures"),
        help="输出目录",
    )
    parser.add_argument(
        "--metric",
        type=str,
        default="RMSE",
        choices=METRICS,
        help="用于选最佳实验及柱状图的指标",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    setup_style()

    files = discover_result_files(args.root, args.glob)
    if not files:
        print(f"[WARN] 在 {args.root} 下未找到符合 {args.glob} 的文件")
        return

    records: List[Record] = []
    for fp in files:
        records.extend(parse_results_file(fp, root=args.root))

    df = to_dataframe(records)
    if df.empty:
        print("[WARN] 没有解析到有效指标行（可能 results.txt 为空或格式不匹配）")
        return

    outputs = summarize(df, outdir=args.outdir, metric=args.metric)
    print("[OK] 数据分析完成，输出文件：")
    for k, v in outputs.items():
        if v is not None:
            print(f"  - {k}: {v}")


if __name__ == "__main__":
    main()
